<?php
var_dump($module);
 
